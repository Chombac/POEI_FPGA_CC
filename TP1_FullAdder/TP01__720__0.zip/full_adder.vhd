library ieee;
use ieee.std_logic_1164.all;


entity full_adder is

	Port ( 
		--Exemple d'entrees
		input 	: in std_logic;
		XX 		: in XX;
		
		--Exemple de sorties
		output 	: out std_logic;
		XX		: out XX
	);

end full_adder;

 

architecture behavior of full_adder is
 
begin

    output <= XX;  --Affectation d'une sortie

end behavior;

