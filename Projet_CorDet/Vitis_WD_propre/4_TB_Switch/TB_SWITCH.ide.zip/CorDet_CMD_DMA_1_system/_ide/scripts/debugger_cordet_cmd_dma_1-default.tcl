# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\CorDet_CMD_DMA_1_system\_ide\scripts\debugger_cordet_cmd_dma_1-default.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\CorDet_CMD_DMA_1_system\_ide\scripts\debugger_cordet_cmd_dma_1-default.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/CoraZ7_for_Corner_detection/export/CoraZ7_for_Corner_detection/hw/TB_SWITCH.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/CorDet_CMD_DMA_1/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/CorDet_CMD_DMA_1/Debug/CorDet_CMD_DMA_1.elf
configparams force-mem-access 0
bpadd -addr &main
