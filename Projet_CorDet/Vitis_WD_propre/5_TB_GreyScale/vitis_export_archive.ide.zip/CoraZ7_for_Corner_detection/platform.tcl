# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\CoraZ7_for_Corner_detection\platform.tcl
# 
# OR launch xsct and run below command.
# source C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\CoraZ7_for_Corner_detection\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {CoraZ7_for_Corner_detection}\
-hw {C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\PS_prog\DMA_CMD_general_projet.xsa}\
-proc {ps7_cortexa9_0} -os {standalone} -fsbl-target {psu_cortexa53_0} -out {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD}

platform write
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform generate
platform active {CoraZ7_for_Corner_detection}
platform active {CoraZ7_for_Corner_detection}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/PS_prog/DMA_CMD_general_projet.xsa}
platform generate -domains 
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform write
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/design_1_wrapper.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/design_1_wrapper.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/design_1_wrapper.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/design_1_wrapper.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform clean
platform generate
catch {platform remove TB_DMA_1}
catch {platform remove TB_DMA_2}
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/LED_rd/design_1_wrapper.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/LED_rd/design_1_wrapper.xsa}
platform clean
platform generate
platform clean
platform generate
bsp reload
bsp config stdin "ps7_coresight_comp_0"
bsp config stdin "ps7_coresight_comp_0"
bsp write
bsp config stdin "ps7_uart_0"
bsp config stdout "ps7_coresight_comp_0"
bsp config stdout "ps7_uart_0"
bsp config microblaze_exceptions "false"
bsp write
bsp reload
catch {bsp regenerate}
platform generate -domains standalone_domain 
bsp write
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform clean
platform generate
bsp reload
bsp write
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform generate -domains 
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/2_TB_CMD_PS_PL/TB_CMD_PS_PL.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/Plateform_config.xsa}
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/3_TB_DMA/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_DMA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille_avec_ILA/TB_DMA_ILA.xsa}
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille_avec_ILA/TB_DMA_ILA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille_avec_ILA/TB_DMA_ILA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille_avec_ILA/TB_DMA_ILA.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille_avec_ILA/TB_DMA_ILA.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille_avec_ILA/TB_DMA_ILA.xsa}
platform generate -domains 
platform clean
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille_avec_ILA/TB_DMA_ILA.xsa}
platform generate
platform clean
platform generate
platform clean
platform generate
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_flux_switch.xsa}
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_SWITCH.xsa}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_SWITCH.xsa}
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/vivado_proj/Tambouille/TB_Pilecran.xsa}
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/5_TB_GreyScale/design_1_wrapper.xsa}
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/5_TB_GreyScale/design_1_wrapper.xsa}
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform clean
platform generate
platform active {CoraZ7_for_Corner_detection}
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD_propre/5_TB_GreyScale/TB_greyscale.xsa}
platform clean
platform generate
platform clean
platform generate
