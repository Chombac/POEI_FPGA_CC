// Library import
#include "xparameters.h"
#include "xil_printf.h"
#include "xil_io.h"
#include <stdio.h>
#include <stdint.h>

//#define Img_path "C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/PS_prog/sample_in_rgb.bin"

//register definition
#define AXI_CMD_BA_ADDRreg XPAR_CUSTOM_CMD_PS_PL_V1_0_0_BASEADDR // 0x44A00000 CMD_PS_PL for reg ctrl
#define AXI_DMA_Start_ADDRreg AXI_CMD_BA_ADDRreg + 0x00
#define AXI_DMA_IMG_W_ADDRreg AXI_CMD_BA_ADDRreg + 0x04
#define AXI_DMA_IMG_H_ADDRreg AXI_CMD_BA_ADDRreg + 0x08
#define AXI_DMA_IMG_BA_LSB_ADDRreg AXI_CMD_BA_ADDRreg + 0x0C
#define AXI_DMA_IMG_BA_MSB_ADDRreg AXI_CMD_BA_ADDRreg + 0x10
#define AXI_VAL_SEUIL_ADDRreg AXI_CMD_BA_ADDRreg + 0x14
#define AXI_SEL_Flux_1_ADDRreg AXI_CMD_BA_ADDRreg + 0x18
#define AXI_SEL_Flux_2_ADDRreg AXI_CMD_BA_ADDRreg + 0x1C
#define AXI_DMA_INPUT_ADDRreg AXI_CMD_BA_ADDRreg + 0x20
#define AXI_OPEN_ADDreg AXI_CMD_BA_ADDRreg + 0x24
#define DDR_IMG_BA XPAR_PS7_DDR_0_S_AXI_BASEADDR + 0x00300000 // DDR Base adress from parameter.h + room for C_program 0x00300000


//Image is stored from adress 0x00100000 + offset 40 0000. (IMG must be stored within DMR range adress CF Xparameter ).
// D�clarer un tableau pour prot�ger l'espace m�moire de la DDR pour �viter de guillotiner le code.
//to adress 0x???
//mwr -bin -file sample_in_rgb.bin 0x44A00140  not working ?


//Value definition for initialisation
#define DefVal_DMA_Start 0x00000000
#define DefVal_IMG_W 0x00000280
#define DefVal_IMG_H 0x000001E0
#define DefVal_BA_LSB DDR_IMG_BA
#define DefVal_BA_MSB 0x00000000
#define DefVal_VAL_SEUIL 0x000000C8
#define DefVal_SEL_Flux_1 0x11111111
#define DefVal_SEL_Flux_2 0x00000000



//Fonction definition
//Init fonction
void bloc_init(){
	Xil_Out32(AXI_DMA_Start_ADDRreg, DefVal_DMA_Start);
	Xil_Out32(AXI_DMA_IMG_W_ADDRreg, DefVal_IMG_W);
	Xil_Out32(AXI_DMA_IMG_H_ADDRreg, DefVal_IMG_H);
	Xil_Out32(AXI_DMA_IMG_BA_LSB_ADDRreg, DefVal_BA_LSB);
	Xil_Out32(AXI_DMA_IMG_BA_MSB_ADDRreg, DefVal_BA_MSB);
	Xil_Out32(AXI_VAL_SEUIL_ADDRreg, DefVal_VAL_SEUIL);
	Xil_Out32(AXI_SEL_Flux_1_ADDRreg, DefVal_SEL_Flux_1);
	Xil_Out32(AXI_SEL_Flux_2_ADDRreg, DefVal_SEL_Flux_2);
	return;
}

//read all value fonction
void read_all_value(){
	xil_printf("\r\n**********************************\r\n");
	xil_printf("DMA_Start_val :  %x \n\r", Xil_In32(AXI_DMA_Start_ADDRreg));
	xil_printf("DMA_IMG_W_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_W_ADDRreg));
	xil_printf("DMA_IMG_H_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_H_ADDRreg));
	xil_printf("DMA_IMG_BA_LSB_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_BA_LSB_ADDRreg));
	xil_printf("DMA_IMG_BA_MSB_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_BA_MSB_ADDRreg));
	xil_printf("VAL_SEUIL :  %x \n\r", Xil_In32(AXI_VAL_SEUIL_ADDRreg));
	xil_printf("SEL_Flux_1_val :  %x \n\r", Xil_In32(AXI_SEL_Flux_1_ADDRreg));
	xil_printf("SEL_Flux_2_val :  %x \n\r", Xil_In32(AXI_SEL_Flux_2_ADDRreg));
	xil_printf("DMA_INPUT_val :  %x \n\r", Xil_In32(AXI_DMA_INPUT_ADDRreg));
	xil_printf("\r\n**********************************\r\n");
	return;
}

void Generate_IMG(unsigned int pattern_select){
//Start adress 0x0040_0000  -- end adress 0x0052_C000  -- 640*480*4 en hexa.
// +0x04 per pixel 1 pixel = 24bits. 307200 pixel dans une image.  640*480
// R = [0 .. 255]
	unsigned int cpt_V = 0;  //cpt_V varie entre 0 et 479
	unsigned int cpt_H = 0; // cpt_H varie entre 0 et 639
	int32_t pixel_value = 0x00000000;
	int32_t Img_BA = DDR_IMG_BA;
	int32_t Img_px_Offset = 0x00000004;
	//int32_t Img_ln_Offset = 640 * 0x04; // 1ligne vaut 640 px *0x04
	int32_t Current_px_Add = 0x00000000;

	switch (pattern_select) {
	  case 0:
		  for (cpt_V = 0; cpt_V < 480; cpt_V++){
		  		for (cpt_H = 0; cpt_H < 640; cpt_H++){
		  			//Current_px_Add = Img_BA + cpt_H*Img_px_Offset + cpt_V*Img_ln_Offset;
		  			Current_px_Add = Img_BA + (cpt_V*640 + cpt_H)*Img_px_Offset;
		  			Xil_Out32(Current_px_Add, pixel_value);
		  			//pixel_value++;
		  		}
		  	}
		  break;
	  case 1:
		  for (cpt_V = 0; cpt_V < 480; cpt_V++){
		  		for (cpt_H = 0; cpt_H < 640; cpt_H++){
		  			//Current_px_Add = Img_BA + cpt_H*Img_px_Offset + cpt_V*Img_ln_Offset;
		  			Current_px_Add = Img_BA + (cpt_V*640 + cpt_H)*Img_px_Offset;
		  			Xil_Out32(Current_px_Add, pixel_value);
		  			pixel_value++;
		  		}
		  	}
		  break;
	  case 2:
			//Un switch case est utilis� pour cr�er un pattern. PATTERN DIFFERENT;
	    break;

	}

	return;
}

int Read_file(){
}


int main(){

	xil_printf("Lecture des registres\n\r");
	read_all_value();
	xil_printf("Initialisation des registres\n\r");
	bloc_init();
	//Chargement de l'image dans la m�moire.
	//mwr -bin -file "C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/PS_prog/sample_in_rgb.bin" 0x00400000 307200
	//D�marrage DMA.
	Xil_Out32(AXI_DMA_Start_ADDRreg, 0x11111111);

	xil_printf("Lecture des registres\n\r");
	read_all_value();
//	//Changement � chaud du flux de lecture.
//	Xil_Out32(AXI_SEL_Flux_1_ADDRreg, 0x11111111);
//	xil_printf("Lecture des registres\n\r");
//	read_all_value();
//	Xil_Out32(AXI_SEL_Flux_1_ADDRreg, 0x00000000);

	return 0;
}
