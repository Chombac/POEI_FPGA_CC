# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\Cora_tb_cmd_ps_pl_config\platform.tcl
# 
# OR launch xsct and run below command.
# source C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\Cora_tb_cmd_ps_pl_config\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {Cora_tb_cmd_ps_pl_config}\
-hw {C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\TB_CMD_PS_PL\TB_CMD_PS_PL.xsa}\
-proc {ps7_cortexa9_0} -os {standalone} -fsbl-target {psu_cortexa53_0} -out {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD}

platform write
platform generate -domains 
platform active {Cora_tb_cmd_ps_pl_config}
platform generate
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/TB_CMD_PS_PL/TB_CMD_PS_PL.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/TB_CMD_PS_PL/TB_CMD_PS_PL.xsa}
platform generate -domains 
platform config -updatehw {C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/TB_CMD_PS_PL/TB_CMD_PS_PL_DMAinputtied.xsa}
platform generate -domains 
