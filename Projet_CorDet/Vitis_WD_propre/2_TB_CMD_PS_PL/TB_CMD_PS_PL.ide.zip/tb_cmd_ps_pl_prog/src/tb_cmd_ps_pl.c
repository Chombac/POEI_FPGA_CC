// Library import
#include "xparameters.h"
#include "xil_printf.h"
#include "xil_io.h"
#include <stdio.h>
#include <stdint.h>
#include <sleep.h>

//register definition
#define AXI_CMD_BA_ADDRreg XPAR_CUSTOM_CMD_PS_PL_V1_0_0_BASEADDR // 0x43C00000 CMD_PS_PL for reg ctrl
#define AXI_DMA_Start_ADDRreg AXI_CMD_BA_ADDRreg + 0x00
#define AXI_DMA_IMG_W_ADDRreg AXI_CMD_BA_ADDRreg + 0x04
#define AXI_DMA_IMG_H_ADDRreg AXI_CMD_BA_ADDRreg + 0x08
#define AXI_DMA_IMG_BA_LSB_ADDRreg AXI_CMD_BA_ADDRreg + 0x0C
#define AXI_DMA_IMG_BA_MSB_ADDRreg AXI_CMD_BA_ADDRreg + 0x10
#define AXI_VAL_SEUIL_ADDRreg AXI_CMD_BA_ADDRreg + 0x14
#define AXI_SEL_Flux_1_ADDRreg AXI_CMD_BA_ADDRreg + 0x18
#define AXI_SEL_Flux_2_ADDRreg AXI_CMD_BA_ADDRreg + 0x1C
#define AXI_DMA_INPUT_ADDRreg AXI_CMD_BA_ADDRreg + 0x20
#define AXI_OPEN_ADDreg AXI_CMD_BA_ADDRreg + 0x24
#define DDR_IMG_BA XPAR_PS7_DDR_0_S_AXI_BASEADDR + 0x00300000 // DDR Base adress from parameter.h + room for C_program 0x00300000


//Value definition for initialisation
#define DefVal_DMA_Start 0x00000000
#define DefVal_IMG_W 0x00000280
#define DefVal_IMG_H 0x000001E0
#define DefVal_BA_LSB DDR_IMG_BA
#define DefVal_BA_MSB 0x00000000
#define DefVal_VAL_SEUIL 0x000000C8
#define DefVal_SEL_Flux_1 0x00000000
#define DefVal_SEL_Flux_2 0x00000000


////Fonction definition
////Init fonction
//void bloc_init(){
//	Xil_Out32(AXI_DMA_Start_ADDRreg, DefVal_DMA_Start);
//	Xil_Out32(AXI_DMA_IMG_W_ADDRreg, DefVal_IMG_W);
//	Xil_Out32(AXI_DMA_IMG_H_ADDRreg, DefVal_IMG_H);
//	Xil_Out32(AXI_DMA_IMG_BA_LSB_ADDRreg, DefVal_BA_LSB);
//	Xil_Out32(AXI_DMA_IMG_BA_MSB_ADDRreg, DefVal_BA_MSB);
//	Xil_Out32(AXI_VAL_SEUIL_ADDRreg, DefVal_VAL_SEUIL);
//	Xil_Out32(AXI_SEL_Flux_1_ADDRreg, DefVal_SEL_Flux_1);
//	Xil_Out32(AXI_SEL_Flux_2_ADDRreg, DefVal_SEL_Flux_2);
//	return;
//}

//read all value fonction
void read_all_value(){
	xil_printf("\r\n**********************************\r\n");
	xil_printf("DMA_Start_val :  %x \n\r", Xil_In32(AXI_DMA_Start_ADDRreg));
	xil_printf("DMA_IMG_W_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_W_ADDRreg));
	xil_printf("DMA_IMG_H_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_H_ADDRreg));
	xil_printf("DMA_IMG_BA_LSB_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_BA_LSB_ADDRreg));
	xil_printf("DMA_IMG_BA_MSB_val :  %x \n\r", Xil_In32(AXI_DMA_IMG_BA_MSB_ADDRreg));
	xil_printf("VAL_SEUIL :  %x \n\r", Xil_In32(AXI_VAL_SEUIL_ADDRreg));
	xil_printf("SEL_Flux_1_val :  %x \n\r", Xil_In32(AXI_SEL_Flux_1_ADDRreg));
	xil_printf("SEL_Flux_2_val :  %x \n\r", Xil_In32(AXI_SEL_Flux_2_ADDRreg));
	xil_printf("DMA_INPUT_val :  %x \n\r", Xil_In32(AXI_DMA_INPUT_ADDRreg));
	xil_printf("DMA_OPEN :  %x \n\r", Xil_In32(AXI_OPEN_ADDreg));
	xil_printf("\r\n**********************************\r\n");
	return;
}


int main(){

	xil_printf("Reading register for confirmation \n\r");
	read_all_value();
//	Xil_Out32(AXI_DMA_Start_ADDRreg, 0x11111111);
//	Xil_Out32(AXI_DMA_IMG_W_ADDRreg, DefVal_IMG_W);
//	Xil_Out32(AXI_DMA_IMG_H_ADDRreg, DefVal_IMG_H);
//	Xil_Out32(AXI_DMA_IMG_BA_LSB_ADDRreg, DefVal_BA_LSB);
//	Xil_Out32(AXI_DMA_IMG_BA_MSB_ADDRreg, 0x11111111);
//	Xil_Out32(AXI_VAL_SEUIL_ADDRreg, DefVal_VAL_SEUIL);
//	Xil_Out32(AXI_SEL_Flux_1_ADDRreg, 0x11111111);
//	Xil_Out32(AXI_SEL_Flux_2_ADDRreg, 0x11111111);
//	Xil_Out32(AXI_SEL_Flux_2_ADDRreg, 0x11111111);
	xil_printf("DMA_INPUT :  %x \n\r", Xil_In32(AXI_DMA_INPUT_ADDRreg));

	return 0;
}
