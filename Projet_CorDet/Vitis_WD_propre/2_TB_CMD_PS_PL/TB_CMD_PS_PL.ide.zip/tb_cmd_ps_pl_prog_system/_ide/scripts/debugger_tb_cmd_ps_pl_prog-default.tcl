# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\tb_cmd_ps_pl_prog_system\_ide\scripts\debugger_tb_cmd_ps_pl_prog-default.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source C:\Users\cleme\Desktop\POEI\Cours\Projet_Corner_detect\Vitis_WD\tb_cmd_ps_pl_prog_system\_ide\scripts\debugger_tb_cmd_ps_pl_prog-default.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Digilent Cora Z7 - 7010 210370AD5271A" && level==0 && jtag_device_ctx=="jsn-Cora Z7 - 7010-210370AD5271A-13722093-0"}
fpga -file C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/tb_cmd_ps_pl_prog/_ide/bitstream/TB_CMD_PS_PL_DMAinputtied.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/Cora_tb_cmd_ps_pl_config/export/Cora_tb_cmd_ps_pl_config/hw/TB_CMD_PS_PL_DMAinputtied.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/tb_cmd_ps_pl_prog/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow C:/Users/cleme/Desktop/POEI/Cours/Projet_Corner_detect/Vitis_WD/tb_cmd_ps_pl_prog/Debug/tb_cmd_ps_pl_prog.elf
configparams force-mem-access 0
bpadd -addr &main
