library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;


entity tp_fsm is
    generic (
        --vous pouvez ajouter des parameres generics ici
    );
    port ( 
		clk			: in std_logic; 
        resetn		: in std_logic
		--a completer
     );
end tp_fsm;

architecture behavioral of tp_fsm is

    type state is (idle, state1, state2); --a modifier avec vos etats
    
    signal current_state : state;  --etat dans lequel on se trouve actuellement
    signal next_state : state;	   --etat dans lequel on passera au prochain coup d'horloge


	
	
	begin

	
		process(clk,resetn)
		begin
            if(resetn='1') then
            
                current_state <= idle;
                 
			elsif(rising_edge(clk)) then
			
				current_state <= next_state;
				
				--a completer avec votre compteur de cycles
				
				
            end if;
		end process;
		
		
		
		
		-- FSM
		process(current_state,XX) --a completer avec vos signaux
		begin		
           case current_state is
              when idle =>
				next_state <= state1; --prochain etat
				
                --signaux pilotes par la fsm
              
              when state1 =>
				next_state <= state1;
				
                --signaux pilotes par la fsm
              
              when state2 =>
				next_state <= state1;
				
                --signaux pilotes par la fsm
              
              
              end case;
              
          
		end process;
		
		
		

end behavioral;